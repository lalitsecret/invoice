import React from 'react'

function Table()
{
	return <div>Table</div>
}
export default Table