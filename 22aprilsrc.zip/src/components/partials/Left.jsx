import React from 'react'
import Filters from './Filters'

function Left()
{
	return <div className="left"><Filters/></div>
}
export default Left