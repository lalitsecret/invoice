import React from 'react'

function Panel3()
{
	return <div>
		panel3
	</div>
}
export default Panel3