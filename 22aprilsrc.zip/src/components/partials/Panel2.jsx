import React from 'react'

function Panel2()
{
	return <div>
		panel2
	</div>
}
export default Panel2