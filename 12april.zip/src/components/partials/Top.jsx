import React from 'react'

function Top()
{
	return <div className="top">Top</div>
}
export default Top