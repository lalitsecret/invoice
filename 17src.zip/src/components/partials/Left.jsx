import React from 'react'

function Left()
{
	return <div className="left">Left</div>
}
export default Left