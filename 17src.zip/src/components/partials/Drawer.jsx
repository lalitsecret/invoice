import React from 'react'
import {useSelector} from 'react-redux'

function Drawer()
{
	let drawer=useSelector(state1=>state1.drawer)

	// information.status

	if(drawer.information)
	{

	let cols=Object.keys(drawer.information).slice(0,5)

	return <div className={drawer.status?"drawer active":"drawer"}>
				<table>
					<thead>
						<tr>
							<th>sno</th>
							<th>name</th>
							<th>value</th>
						</tr>
					</thead>
					<tbody>
						{cols.map((x,i) =>
							<tr>
								<td>{i+1}</td>
								<td>{x}</td>
								<td>{drawer.information[x]}</td>
							
							</tr>
						)}
					</tbody>
				</table>
	</div>
	}
	else
	{
		return <div className={drawer.status?"drawer active":"drawer"}>
			<h1>nothing to show</h1>
	</div>
	}
}
export default Drawer