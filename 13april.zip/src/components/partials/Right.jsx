import React from 'react'
import Table from '../common/Table'
function Right()
{
	return <div className="right">
		<div className="table">
			<Table/>
		</div>		
		<div className="subtotal">
			grand total
		</div>		
	</div>
}
export default Right
